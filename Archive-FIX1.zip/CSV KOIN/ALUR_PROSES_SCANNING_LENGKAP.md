# Alur Proses Scanning (Langkah demi Langkah)

Dokumen ini menjelaskan alur proses teknis yang terjadi di latar belakang saat pengguna mengklik tombol "Start Scan" pada tab "Scanning". Proses ini diorkestrasi oleh `PriceScanner` dan bertujuan untuk menemukan peluang arbitrase antara CEX dan DEX secara sistematis dan efisien.

---

### Tahap 1: Inisiasi (Saat Tombol "Start Scan" Diklik)

1.  **Aksi Pengguna & Pemicu UI**:
    *   Pengguna mengklik tombol "Start Scan".
    *   Komponen `scanning-tab.js` memanggil metode `startScanning()` yang ada di `scannerMixin`.

2.  **Kirim Status ONLINE**:
    *   `PriceScanner` segera memanggil `TelegramService` untuk mengirim notifikasi status ke grup Telegram.
    *   Pesan yang dikirim: `<b>#APP_NAME</b>\nUSER: <b>NICKNAME_PENGGUNA</b> [<b>ONLINE</b>]`.
    *   `APP_NAME` diambil dari `config_app.js` dan `NICKNAME_PENGGUNA` dari `SETTING_GLOBAL`.

3.  **Fetch Data Real-time Awal**:
    *   Sebelum memulai loop, `PriceScanner` memanggil `RealtimeDataFetcher` untuk mengambil data yang akan digunakan bersama untuk semua perhitungan dalam sesi scan ini.
    *   Data yang diambil meliputi:
        *   **Harga Gas (Gwei)**: Untuk setiap *chain* yang aktif (misal: BSC, Polygon), aplikasi memanggil RPC untuk mendapatkan harga gas saat ini.
        *   **Harga Token Native**: Harga token untuk bayar gas (misal: BNB, MATIC) diambil dari API Binance dalam kurs USDT.
        *   **Kurs USDT/IDR**: Kurs Rupiah terbaru diambil dari Tokocrypto/Indodax.
    *   Data ini di-cache selama 30 detik untuk efisiensi, jadi tidak di-fetch berulang kali untuk setiap token.

---

### Tahap 2: Pemrosesan Batch (Grup Token)

Untuk mengelola beban API dan menghindari *rate-limiting*, daftar total token yang akan dipindai tidak diproses sekaligus.

1.  **Pembagian Grup (Batch)**:
    *   Daftar token yang telah difilter dibagi menjadi grup-grup kecil. Ukuran grup ini ditentukan oleh pengaturan `tokensPerBatch` (misal: 3 token per grup).

2.  **Pemrosesan Paralel dalam Grup**:
    *   Untuk setiap grup, semua token di dalamnya (`anggota grup`) diproses **secara paralel (bersamaan)** menggunakan `Promise.all`. Artinya, jika ada 3 token dalam satu batch, permintaan data untuk ketiga token tersebut dimulai pada saat yang hampir bersamaan.

3.  **Jeda Antar Grup**:
    *   Setelah semua token dalam satu grup selesai diproses, ada jeda waktu (diambil dari `jedaTimeGroup` di `SETTING_GLOBAL`) sebelum aplikasi melanjutkan ke grup berikutnya. Ini adalah mekanisme utama untuk menghindari *rate-limiting* dari API CEX dan DEX.

---

### Tahap 3: Inti Proses per Token (Di dalam `_processToken`)

Untuk setiap token yang diproses secara paralel di dalam batch, urutan operasinya adalah sebagai berikut:

1.  **Fetch Harga CEX (`CexPriceFetcher`)**:
    *   Langkah pertama adalah mengambil *order book* dari CEX yang terhubung dengan token tersebut (misal: GATE, BINANCE).
    *   `cexFetcher.getOrderbook()` dipanggil untuk mendapatkan harga jual terbaik (`bestAsk`) dan harga beli terbaik (`bestBid`).
    *   Hasil harga CEX ini kemudian dikirim ke UI melalui callback `onCexResult` agar bisa ditampilkan lebih dulu di kolom CEX pada tabel.

2.  **Fetch Harga DEX & Kalkulasi PNL (Digabung per DEX)**:
    *   Setelah harga CEX didapat, aplikasi akan melakukan loop untuk **setiap DEX** yang aktif untuk token tersebut (misal: Kyber, Odos, Flytrade).
    *   **Untuk setiap DEX**:
        *   `dexFetcher.getQuotes()` dipanggil untuk mendapatkan simulasi harga swap untuk **dua arah**:
            *   **Arah CEX → DEX**: Simulasi menjual `nama_token` (misal: CAKE) untuk mendapatkan `nama_pair` (misal: USDT).
            *   **Arah DEX → CEX**: Simulasi menjual `nama_pair` (misal: USDT) untuk mendapatkan `nama_token` (misal: CAKE).
        *   **Segera setelah** data dari satu DEX diterima, `PnlCalculator` dipanggil untuk menghitung PNL.
        *   Callback `onPnlResult` dipanggil untuk mengirim hasil PNL **per DEX** ke UI. Ini memungkinkan sel tabel DEX terisi secara *real-time* satu per satu, tanpa menunggu semua DEX selesai.

3.  **Kirim Sinyal Telegram**:
    *   Di dalam loop DEX, setelah PNL dihitung, `_checkAndSendSignal` akan memeriksa hasilnya.
    *   Jika `PNL (USD)` yang dihasilkan melebihi ambang batas (`minPnl` dari filter), maka `TelegramService` akan dipanggil.
    *   Sebuah pesan sinyal yang terformat rapi berisi semua detail (Token, Chain, CEX, DEX, Arah, PNL, dll.) akan dikirim ke grup Telegram.

4.  **Update Status & Callback**:
    *   Setelah loop untuk semua DEX pada satu token selesai, statistik dipembaruan.
    *   Callback `onTokenComplete` dipanggil untuk menandakan token tersebut telah selesai diproses sepenuhnya.

---

### Tahap 4: Penyelesaian (Setelah Semua Batch Selesai)

1.  **Proses Selesai**:
    *   Setelah semua grup token selesai dipindai, `PriceScanner` akan memanggil callback `onComplete`.

2.  **Kirim Status OFFLINE**:
    *   Pesan status "OFFLINE" dikirim ke Telegram untuk menandakan proses telah berakhir.

3.  **Update UI Final**:
    *   `scannerMixin` menerima callback `onComplete`.
    *   Progress bar di UI akan mencapai 100%.
    *   Ringkasan hasil scan (jumlah sukses, error, sinyal, dan durasi) akan ditampilkan melalui toast notifikasi.
